﻿using System.Reflection;

[assembly: AssemblyTitle("Virtual_Buttons")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Virtual_Buttons")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2022")]
[assembly: AssemblyVersion("1.0.0.*")]

