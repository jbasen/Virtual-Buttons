﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Https;

namespace Virtual_Buttons_Integration
{
	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Virtual_Buttons
	{
		#region Declarations
		private static Debug_Options Debug;
		#endregion

		//****************************************************************************************
		// 
		//  Virtual_Buttons	-	Default Constructor
		// 
		//****************************************************************************************
		public Virtual_Buttons()
		{
		}

		//****************************************************************************************
		// 
		//  Trigger_Virtual_Button	-	Send command to trigger an Alexa virtual button
		//								Requires the virtual button skill 
		// 
		//****************************************************************************************
		public void Trigger_Virtual_Button(short Button, string Access_Code, short Debug)
		{
			Set_Debug_Message_Output(Debug);

			Debug_Message("Trigger_Virtual_Button", "Button = " + Button);

			#region Create url
			string url = " https://api.virtualbuttons.com/v1";
			Debug_Message("Trigger_Virtual_Button", "URL: " + url);
			#endregion

			#region JSON
			string json = "{\"virtualButton\":" + Button + ",\"accessCode\":\"" + Access_Code + "\"}";
			Debug_Message("Trigger_Virtual_Button", "JSON: " + json);
			#endregion

			#region Make HTTPS Request
			try
			{
				#region Create Client and Set Options
				HttpsClient client = new HttpsClient();
				//turn verification off, to stop it taking a dump on cert errors
				client.HostVerification = false;
				client.PeerVerification = false;
				client.Verbose = false;
				#endregion

				#region Create Request and Populate It
				HttpsClientRequest request = new HttpsClientRequest();
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("charset", "utf8");
				request.Header.SetHeaderValue("Accept", "*/*");
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));
				request.Url.Parse(url);
				#endregion

				#region Dispatch Request and Get Response
				HttpsClientResponse response;
				response = client.Dispatch(request);
				#endregion

				#region Manage Response
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Virtual_Buttons - Trigger_Virtual_Button - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Trigger_Virtual_Button", "ContentString = " + ContentString);
				}
				#endregion
			}
			catch (Exception e)
			{
				string err = "Virtual_Buttons - Trigger_Virtual_Button - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Virtual_Buttons.Debug = Debug_Options.None;
					break;

				case 1:
					Virtual_Buttons.Debug = Debug_Options.Console;
					break;

				case 2:
					Virtual_Buttons.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Virtual_Buttons.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Tailwind - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Tailwind - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
